import inspect
import json
from dataclasses import asdict

from promptflow.core.tool import ToolInvoker
from promptflow.core.flow import Flow
from promptflow.contracts.tool import ToolType
from promptflow.utils.tool_utils import function_to_tool_definition


class DefaultToolInvoker(ToolInvoker):
    def invoke_tool(self, f, *args, **kwargs):
        cur_flow = Flow.active_instance()
        if cur_flow is None:
            return f(*args, **kwargs)  # Do nothing if not in a flow context
        signature = inspect.signature(f)
        argnames = [arg for arg in signature.parameters]
        # Try resolve the variable name of prompt parameter.
        return cur_flow.invoke_tool_with_cache(f, argnames, args, kwargs)


def dump(func, name=None, description=None):
    try:
        if not func.__tool:
            func.__tool = function_to_tool_definition(func, type=ToolType.PYTHON)
        if name:
            func.__tool.name = name
        if description:
            func.__tool.description = description
        data = asdict(func.__tool, dict_factory=lambda x: {k: v for (k, v) in x if v is not None and k != "outputs"})
        return json.dumps(data, indent=2)
    except Exception as e:
        raise Exception("Dump tool failed. ") from e
