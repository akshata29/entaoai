import contextvars
import copy
import functools
import inspect
import re
import uuid
from dataclasses import dataclass
from datetime import datetime
from multiprocessing.pool import ThreadPool
from pathlib import Path
from types import GeneratorType
from typing import AbstractSet, Any, Callable, Dict, List, Mapping, Optional, Tuple

from promptflow.contracts.flow import Flow as FlowDefinition
from promptflow.contracts.flow import InputAssignment, InputValueType, Node
from promptflow.contracts.run_info import FlowRunInfo
from promptflow.contracts.run_info import RunInfo as NodeRunInfo
from promptflow.contracts.run_info import Status
from promptflow.core import RunTracker
from promptflow.core.cache_manager import AbstractCacheManager
from promptflow.core.flow import Flow
from promptflow.core.tool import ToolInvoker
from promptflow.core.tools_manager import ToolsManager
from promptflow.exceptions import ErrorTarget, PromptflowException, UserErrorException
from promptflow.executor.common import _load_tools_and_update_node_inputs
from promptflow.executor.flow_request_validator import FlowRequestValidator
from promptflow.executor.tool_invoker import DefaultToolInvoker
from promptflow.storage.run_storage_v2 import AbstractRunStorage, DummyRunStorage
from promptflow.utils.executor_logger import bulk_logger, logger
from promptflow.utils.utils import count_and_log_progress, set_context, transpose

LINE_NUMBER_KEY = "line_number"  # Using the same key with portal.


@dataclass
class LineResult:
    """The result of a line process."""

    output: Mapping[str, Any]  # The output of the line.
    # The node output values to be used as aggregation inputs, if no aggregation node, it will be empty.
    aggregation_inputs: Mapping[str, Any]
    run_info: FlowRunInfo  # The run info of the line.
    node_run_infos: Mapping[str, NodeRunInfo]  # The run info of the nodes in the line.


@dataclass
class BulkResult:
    """The result of a bulk run."""

    outputs: List[Mapping[str, Any]]
    metrics: Mapping[str, Any]


class FlowExecutor:
    """This class is used to execute a single flow for different inputs."""

    def __init__(
        self,
        flow: FlowDefinition,
        connections: dict,
        run_tracker: RunTracker,
        cache_manager: AbstractCacheManager,
        loaded_tools: Mapping[str, Callable],
        *,
        nthreads=32,
        is_bulk_test: bool = False,
        raise_ex: bool = False,
    ):
        self._flow = flow
        self._connections = connections
        self._aggregation_inputs_references = self._get_aggregation_inputs_properties(flow)
        self._aggregation_nodes = {node.name for node in self._flow.nodes if node.reduce}
        self._is_bulk_test = is_bulk_test
        self._nthreads = nthreads
        self._run_tracker = run_tracker
        self._cache_manager = cache_manager
        try:
            self._tools_manager = ToolsManager(loaded_tools)
            tool_to_meta = {tool.name: tool for tool in flow.tools}
            custom_tools = {
                node.name: self._tools_manager._load_custom_tool(tool_to_meta[node.tool], node.name)
                for node in flow.nodes
                if not self._tools_manager.loaded(node.name)
            }
            self._tools_manager.load_tools(custom_tools)
        except PromptflowException as e:
            # For PromptflowException, we don't wrap it, because need generate ErrorResponse by inner exception.
            # Will try to find one common way to handle this case.
            raise e
        except Exception as e:
            raise ValueError(f"Failed to load custom tools for flow due to exception:\n {e}.") from e
        for node in flow.nodes:
            self._tools_manager.assert_loaded(node.name)
        self._raise_ex = raise_ex

    @classmethod
    def create(
        cls,
        flow_file: Path,
        connections: dict,
        working_dir: Optional[Path] = None,
        storage: Optional[AbstractRunStorage] = None,
        raise_ex: bool = False,
    ) -> 'FlowExecutor':
        flow = FlowDefinition.from_yaml(flow_file, working_dir=working_dir)
        # ensure_flow_valid including validation + resolve
        # Todo: 1) split pure validation + resovle from below method 2) provide completed validation()
        flow = FlowRequestValidator.ensure_flow_valid(flow, connections)

        if storage is None:
            storage = DummyRunStorage()
        run_tracker = RunTracker(storage)  # Todo: make RunTracker support such parameter type in definition

        cache_manager = AbstractCacheManager.init_from_env()

        loaded_tools = _load_tools_and_update_node_inputs(flow)

        ToolInvoker.activate(DefaultToolInvoker())

        return FlowExecutor(
            flow=flow,  # unresolved flow for validation purpose
            connections=connections,
            run_tracker=run_tracker,
            cache_manager=cache_manager,
            loaded_tools=loaded_tools,
            raise_ex=raise_ex,
        )

    def validate_inputs(self, input_data: Mapping[str, Any]):
        return FlowRequestValidator.ensure_flow_inputs_type(self._flow, input_data)

    def collect_run_infos(self):
        return self._run_tracker.collect_all_run_infos_as_dicts()

    @property
    def default_inputs_mapping(self):
        return {key: f"data.{key}" for key in self._flow.inputs}

    @property
    def has_aggregation_node(self):
        return len(self._aggregation_nodes) > 0

    @property
    def aggregation_nodes(self):
        return self._aggregation_nodes

    @staticmethod
    def _get_aggregation_inputs_properties(flow: FlowDefinition) -> AbstractSet[str]:
        normal_node_names = {node.name for node in flow.nodes if flow.is_normal_node(node.name)}
        properties = set()
        for node in flow.nodes:
            if node.name in normal_node_names:
                continue
            for value in node.inputs.values():
                if not value.value_type == InputValueType.NODE_REFERENCE:
                    continue
                if value.value in normal_node_names:
                    properties.add(value.serialize())
        return properties

    def _collect_lines(self, indexes: List[int], kvs: Mapping[str, List]) -> Mapping[str, List]:
        """Collect the values from the kvs according to the indexes."""
        return {k: [v[i] for i in indexes] for k, v in kvs.items()}

    def _fill_lines(self, idxes, values, nlines):
        """Fill the values into the result list according to the indexes."""
        result = [None] * nlines
        for idx, value in zip(idxes, values):
            result[idx] = value
        return result

    def _handle_failures(self, run_infos: List[FlowRunInfo]):
        failed = [i for i, r in enumerate(run_infos) if r.status == Status.Failed]
        failed_msg = None
        if len(failed) > 0:
            failed_indexes = ",".join([str(i) for i in failed])
            first_fail_exception = run_infos[failed[0]].error["message"]
            if not self._is_bulk_test:
                failed_msg = "Flow run failed due to the error: " + first_fail_exception
                raise Exception(failed_msg)

            failed_msg = (
                f"{len(failed)}/{len(run_infos)} flow run failed, indexes: [{failed_indexes}],"
                f" exception of index {failed[0]}: {first_fail_exception}"
            )
            logger.error(failed_msg)

    def _exec_batch_with_threads(self, batch_inputs: List[dict], parent: FlowRunInfo) -> List[LineResult]:
        nlines = len(batch_inputs)
        # Copy context variables to new threads,
        # otherwise previously set context variables will be lost in new threads.
        parent_context = contextvars.copy_context()
        with ThreadPool(processes=self._nthreads, initializer=set_context, initargs=(parent_context,)) as pool:
            inputs = pool.imap_unordered(
                self._exec_in_thread,
                ((inputs, parent, i) for i, inputs in enumerate(batch_inputs)),
            )
            results_gen = count_and_log_progress(
                inputs=inputs,
                logger=bulk_logger,
                total_count=nlines,
                formatter="Finished {count} / {total_count} lines.",
            )
            return sorted(list(results_gen), key=lambda r: r.run_info.index)

    def exec_batch(self, batch_inputs: List[dict], parent: FlowRunInfo) -> Dict[str, List]:
        results = self._exec_bulk(batch_inputs, parent)
        output_keys = list(self._flow.outputs.keys())
        batch_results = transpose([result.output for result in results], keys=output_keys)
        return batch_results

    def _exec_bulk(self, batch_inputs: List[dict], parent: FlowRunInfo) -> List[LineResult]:
        results = self._exec_batch_with_threads(batch_inputs, parent)
        run_infos = [r.run_info for r in results]
        self._handle_failures(run_infos)
        if not self.aggregation_nodes:
            return results

        logger.info("Executing aggregation nodes...")
        inputs = transpose(batch_inputs, keys=list(self._flow.inputs.keys()))
        aggregation_inputs = transpose(
            [result.aggregation_inputs for result in results],
            keys=self._aggregation_inputs_references,
        )
        succeeded = [i for i, r in enumerate(run_infos) if r.status == Status.Completed]
        succeeded_inputs = self._collect_lines(succeeded, inputs)
        succeeded_aggregation_inputs = self._collect_lines(succeeded, aggregation_inputs)
        try:
            self.exec_aggregation(succeeded_inputs, succeeded_aggregation_inputs, parent)
            logger.info("Finish executing aggregation nodes.")
        except PromptflowException as e:
            # For PromptflowException, we already do classification, so throw directly.
            raise e
        except Exception as e:
            raise Exception(f"Failed to run aggregation nodes:\n {e}.") from e
        return results

    @staticmethod
    def _try_get_aggregation_input(val: InputAssignment, aggregation_inputs: dict):
        if val.value_type != InputValueType.NODE_REFERENCE:
            return val
        serialized_val = val.serialize()
        if serialized_val not in aggregation_inputs:
            return val
        return InputAssignment(value=aggregation_inputs[serialized_val])

    def get_status_summary(self, run_id: str):
        return self._run_tracker.get_status_summary(run_id)

    def exec_aggregation(
        self,
        inputs: Mapping[str, Any],
        aggregation_inputs: Mapping[str, Any],
        run_info: Optional[FlowRunInfo] = None,
    ):
        if not self._flow.has_aggregation_node:
            return {}
        nodes = [copy.deepcopy(node) for node in self._flow.nodes if node.reduce]
        # Update the inputs of the aggregation nodes with the aggregation inputs.
        for node in nodes:
            node.inputs = {
                k: FlowExecutor._try_get_aggregation_input(v, aggregation_inputs) for k, v in node.inputs.items()
            }

        flow = Flow(
            name=self._flow.name,
            run_tracker=self._run_tracker,
            cache_manager=self._cache_manager,
            flow_run_info=run_info,
        )
        flow.start()
        try:
            self._traverse_nodes_inner(flow, inputs, nodes)
            return {}
        finally:
            flow.end()

    def exec(self, inputs: dict) -> dict:
        result = self._exec(inputs)
        return result.output or {}

    def _exec_in_thread(self, args) -> LineResult:
        inputs, parent, index = args
        self._run_tracker._activate_in_context()
        results = self._exec(inputs, parent, index)
        self._run_tracker._deactivate_in_context()
        return results

    def _extract_aggregation_inputs(self, nodes_outputs: dict):
        return {
            prop: self._extract_aggregation_input(nodes_outputs, prop) for prop in self._aggregation_inputs_references
        }

    def _extract_aggregation_input(self, nodes_outputs: dict, aggregation_input_property: str):
        assign = InputAssignment.deserialize(aggregation_input_property)
        return self._parse_value(assign, nodes_outputs, {})

    def ensure_flow_inputs_type(
        self, inputs: Mapping[str, Any], raise_for_missing_input: Optional[bool] = True
    ) -> Mapping[str, Any]:
        return FlowRequestValidator.ensure_flow_inputs_type(
            flow=self._flow,
            inputs=inputs,
            raise_for_missing_input=raise_for_missing_input,
        )

    def exec_line(
        self, inputs: Mapping[str, Any], index: Optional[int] = None, parent: Optional[FlowRunInfo] = None
    ) -> LineResult:
        # For flow run, validate inputs as default
        return self._exec(inputs, parent, index, validate_inputs=True)

    def exec_bulk(
        self,
        inputs: List[Mapping[str, Any]],
        run_id: str = None,
    ) -> BulkResult:
        """
        The entry points for bulk run execution

        inputs:
            The batch inputs for the flow in the executor
        run_id:
            parent run id for current flow run, if any
            Todo: discuss with sdk if we keep this

        Return:
            BulkResults including flow results and metrics
        """
        flow_id = self._flow.id
        # create parent run info with input run_id
        parent_run_info = None
        if run_id:
            # if run_id specified, the child run_id shall be generated based on this run_id
            parent_run_info = FlowRunInfo(
                run_id=run_id,
                status=Status.Running,
                error=None,
                inputs=None,
                output=None,
                metrics=None,
                request=None,
                parent_run_id="",
                root_run_id=run_id,
                source_run_id=None,
                flow_id=flow_id,
                start_time=datetime.utcnow(),
                end_time=None,
                index=None,
            )

        line_results = self._exec_bulk(inputs, parent_run_info)
        outputs = [{
            LINE_NUMBER_KEY: r.run_info.index, **r.output
        } for r in line_results if r.run_info.status == Status.Completed
        ]
        return BulkResult(outputs=outputs, metrics={})  # Todo: enrich the metric collection

    def exec_bulk_with_inputs_mapping(
        self,
        inputs: Mapping[str, List[Mapping[str, Any]]],
        inputs_mapping: Mapping[str, Any],
        run_id: str = None,  # parent run id
    ) -> BulkResult:
        """
        Another entry points for bulk run execution.
        This api is mostly consumed by sdk team for inputs convenience, instead of calling exec_bulk() directly

        inputs:
            the un-mapped inputs structure, for example
            {
                "data": [{"answer": 123, "question": "dummy"}, {"answer": 12, "question": "dummy2"}],
                "output": [{"answer": 321}, {"answer": 43}]
                "baseline": [{"answer": 33}, {"answer": 43}]
            }

        inputs_mapping:
           the mapping relationship for the inputs data, for example
            {
                "question": "data.question",  # Question from the data
                "groundtruth": "data.answer",  # Answer from the data
                "baseline": "baseline.answer",  # Answer from the baseline
                "answer": "output.answer",  # Answer from the output
                "deployment_name": "text-davinci-003",  # literal value
            }

        run_id:
            parent run id for current flow run, if any
            Todo: discuss with sdk if we keep this

        Return:
            BulkResults including flow results and metrics
        """
        # resolve final inputs with inputs_mapping
        resolved_inputs = self.apply_inputs_mapping_for_all_lines(inputs, inputs_mapping)
        return self.exec_bulk(resolved_inputs, run_id)

    def _exec(
        self,
        inputs: Mapping[str, Any],
        parent: Optional[FlowRunInfo] = None,
        index: Optional[int] = None,
        validate_inputs: bool = False,  # The flag is True for Flow Run, False for bulk run as default
    ) -> LineResult:
        """
        execute line run

        Args:
            inputs (Mapping): flow inputs
            parent (FlowRunInfo): The parent of this line run
            index: line number for batch inputs
            validate_inputs:
                Flag to indicate if input validation needed. It is used along with "_raise_ex" to
                define if exception shall be raised if inputs validation failed
                The flag is True for Flow Run, False for bulk run as default


        Returns:
            LineResult: Line run result
        """
        run_id = str(uuid.uuid4()) if index is None or parent is None else f"{parent.run_id}_{index}"
        run_info: FlowRunInfo = self._run_tracker.start_flow_run(
            flow_id=parent.flow_id if parent else self._flow.id,
            root_run_id=run_id if parent is None else parent.root_run_id,
            run_id=run_id,
            parent_run_id="" if parent is None else parent.run_id,
        )
        run_info.index = index
        if parent:
            run_info.variant_id = parent.variant_id
        self._run_tracker.set_inputs(run_id, inputs)
        output = {}
        aggregation_inputs = {}
        try:
            if validate_inputs:
                self.validate_inputs(inputs)
            output, nodes_outputs = self.traverse_nodes(inputs, run_info)
            self._run_tracker.end_run(run_id, result=output)
            aggregation_inputs = self._extract_aggregation_inputs(nodes_outputs)
        except Exception as e:
            self._run_tracker.end_run(run_id, ex=e)
            if self._raise_ex:
                raise
        finally:
            self._run_tracker.persist_flow_run(run_info)
        # TODO: Refine the logic here to avoid traversing all the nodes:
        # 1. Initialize a new run tracker in the thread
        # 2. Collect all nodes in the run tracker
        node_runs = self._run_tracker.collect_child_node_runs(run_id)
        return LineResult(output, aggregation_inputs, run_info, {node_run.node: node_run for node_run in node_runs})

    def _traverse_nodes_inner(
        self,
        flow: Flow,
        inputs,
        nodes: List[Node],
    ) -> dict:
        results = {}
        for node in nodes:
            if node.skip:
                skip_condition = self._parse_value(node.skip.condition, results, inputs)
                if skip_condition == node.skip.condition_value:
                    return_value = self._parse_value(node.skip.return_value, results, inputs)
                    results[node.name] = return_value
                    continue
            kwargs = {name: self._parse_value(i, results, inputs) for name, i in (node.inputs or {}).items()}
            f = self._tools_manager.get_tool(node.name)
            flow.current_node = node
            result = f(**kwargs)
            flow.current_node = None
            results[node.name] = result
        return results

    def extract_outputs(self, nodes_outputs, flow_inputs):
        outputs = {}
        for name, output in self._flow.outputs.items():
            if output.reference.value_type == InputValueType.LITERAL:
                outputs[name] = output.reference.value
                continue
            if output.reference.value_type == InputValueType.FLOW_INPUT:
                outputs[name] = flow_inputs[output.reference.value]
                continue
            if output.reference.value_type != InputValueType.NODE_REFERENCE:
                raise NotImplementedError(f"Unsupported output type {output.reference.value_type}")
            node = next((n for n in self._flow.nodes if n.name == output.reference.value), None)
            if not node:
                raise ValueError(f"Invalid node name {output.reference.value}")
            if node.reduce:
                # Note that the reduce node referenced in the output is not supported.
                continue
            if node.name not in nodes_outputs:
                raise ValueError(f"Node {output.reference.value} not found in results.")
            node_result = nodes_outputs[output.reference.value]
            outputs[name] = FlowExecutor._parse_node_property(
                output.reference.value, node_result, output.reference.property
            )
        return outputs

    def traverse_nodes(self, inputs, flow_run_info: FlowRunInfo) -> Tuple[dict, dict]:
        flow = Flow(
            name=self._flow.name,
            run_tracker=self._run_tracker,
            cache_manager=self._cache_manager,
            flow_run_info=flow_run_info,
        )
        flow.start()
        batch_nodes = [node for node in self._flow.nodes if not node.reduce]
        outputs = {}
        try:
            nodes_outputs = self._traverse_nodes_inner(flow, inputs, batch_nodes)
            outputs = self.extract_outputs(nodes_outputs, inputs)
            flow.end()
        except Exception:
            flow.end()
            raise
        return outputs, nodes_outputs

    @staticmethod
    def _parse_value(i: InputAssignment, results: dict, flowinputs: dict):
        if i.value_type == InputValueType.LITERAL:
            return i.value
        if i.value_type == InputValueType.FLOW_INPUT:
            return flowinputs[i.value]
        if i.value_type == InputValueType.NODE_REFERENCE:
            if i.section != "output":
                raise UnsupportedReference(f"Unsupported reference {i.serialize()}")
            return FlowExecutor._parse_node_property(i.value, results[i.value], i.property)
        raise NotImplementedError(f"The value type {i.value_type} cannot be parsed for input {i}")

    property_pattern = r"(\w+)|(\['.*?'\])|(\[\d+\])"

    @staticmethod
    def _parse_node_property(node_name, node_val, property=""):
        val = node_val
        property_parts = re.findall(FlowExecutor.property_pattern, property)
        try:
            for part in property_parts:
                part = [p for p in part if p][0]
                if part.startswith("[") and part.endswith("]"):
                    index = part[1:-1]
                    if index.startswith("'") and index.endswith("'") or index.startswith('"') and index.endswith('"'):
                        index = index[1:-1]
                    elif index.isdigit():
                        index = int(index)
                    else:
                        raise InvalidReferenceProperty(f"Invalid index {index} when accessing property {property}")
                    val = val[index]
                else:
                    if isinstance(val, dict):
                        val = val[part]
                    else:
                        val = getattr(val, part)
        except (KeyError, IndexError, AttributeError) as e:
            raise InvalidReferenceProperty(f"Invalid property {property} for the node {node_name}") from e
        return val

    @staticmethod
    def apply_inputs_mapping_legacy(
        inputs: Mapping[str, Mapping[str, Any]],
        inputs_mapping: Mapping[str, str],
    ) -> Dict[str, Any]:
        """Apply inputs mapping to inputs for legacy contract.
        We use different inputs mapping foramt for new contract.

        For example:
        inputs: {
            "data": {"answer": 123, "question": "dummy"},
            "output": {"answer": 321},
            "baseline": {"answer": 322},
        }
        inputs_mapping: {
            "question": "data.question",  # Question from the data
            "groundtruth": "data.answer",  # Answer from the data
            "baseline": "baseline.answer",  # Answer from the baseline
            "answer": "output.answer",  # Answer from the output
            "deployment_name": "text-davinci-003",  # literal value
        }

        Returns: {
            "question": "dummy",
            "groundtruth": 123,
            "baseline": 322,
            "answer": 321,
            "deployment_name": "text-davinci-003",
        }
        """
        result = {}
        for k, v in inputs_mapping.items():
            if "." not in v:
                result[k] = v
                continue
            source, key = v.split(".", 1)
            if source in inputs:  # Value from inputs
                if key not in inputs[source]:
                    raise MappingSourceNotFound(
                        f"Failed to do input mapping for '{v}', can't find key '{key}' in dict '{source}', "
                        + f"all keys are {inputs[source].keys()}."
                    )
                result[k] = inputs[source][key]
            else:
                result[k] = v  # Literal value
        return result

    @staticmethod
    def apply_inputs_mapping(
        inputs: Mapping[str, Mapping[str, Any]],
        inputs_mapping: Mapping[str, str],
    ) -> Dict[str, Any]:
        """Apply inputs mapping to inputs for new contract.

        For example:
        inputs: {
            "data": {"answer": 123, "question": "dummy"},
            "baseline": {"answer": 322},
        }
        inputs_mapping: {
            "question": "${data.question}",  # Question from the data
            "groundtruth": "${data.answer}",  # Answer from the data
            "baseline": "${baseline.answer}",  # Answer from the baseline
            "deployment_name": "text-davinci-003",  # literal value
        }

        Returns: {
            "question": "dummy",
            "groundtruth": 123,
            "baseline": 322,
            "deployment_name": "text-davinci-003",
        }
        """
        import re

        result = {}
        for map_to_key, map_value in inputs_mapping.items():
            match = re.search(r"^\${([^{}]+)}$", map_value)
            if match is not None:
                pattern = match.group(1)
                # Could also try each paire of key value from inputs to match the pattern.
                # But split pattern by '.' is one deterministic way.
                # So, give key with less '.' higher priority.
                splitted_str = pattern.split(".")
                find_match = False
                for i in range(1, len(splitted_str)):
                    key = ".".join(splitted_str[:i])
                    source = ".".join(splitted_str[i:])
                    if key in inputs and source in inputs[key]:
                        find_match = True
                        result[map_to_key] = inputs[key][source]
                        break
                if not find_match:
                    raise MappingSourceNotFound(
                        f"Failed to do input mapping for '{map_value}', can't find corresponding input."
                    )
            else:
                result[map_to_key] = map_value  # Literal value
        return result

    @staticmethod
    def _merge_input_dicts_by_line(
        input_dict: Mapping[str, List[Mapping[str, Any]]],
    ) -> List[Mapping[str, Mapping[str, Any]]]:
        for input_key, list_of_one_input in input_dict.items():
            if len(list_of_one_input) == 0:
                raise EmptyInputListError(f"List from key '{input_key}' is empty.")

        # For now, the majoriy cases only have one input, so we just return.
        if len(input_dict) == 1:
            key = list(input_dict.keys())[0]
            value = list(input_dict.values())[0]
            return [{key: each_line} for each_line in value]
        all_lengths_without_line_number = {
            input_key: len(list_of_one_input)
            for input_key, list_of_one_input in input_dict.items()
            if not any(LINE_NUMBER_KEY in one_item for one_item in list_of_one_input)
        }
        if len(set(all_lengths_without_line_number.values())) > 1:
            raise LineNumberNotAlign(
                "Line numbers are not aligned. Some lists have dictionaries missing the 'line_number' key, "
                f"and the lengths of these lists are different. List lengths: {all_lengths_without_line_number}"
            )

        tmp_dict = {}
        for input_key, list_of_one_input in input_dict.items():
            if input_key in all_lengths_without_line_number:
                # Assume line_number start from 0.
                for index, one_line_item in enumerate(list_of_one_input):
                    if index not in tmp_dict:
                        tmp_dict[index] = {}
                    tmp_dict[index][input_key] = one_line_item
            else:
                for one_line_item in list_of_one_input:
                    if LINE_NUMBER_KEY in one_line_item:
                        index = one_line_item[LINE_NUMBER_KEY]
                        if index not in tmp_dict:
                            tmp_dict[index] = {}
                        tmp_dict[index][input_key] = one_line_item
        return list(filter(lambda dict: len(dict) == len(input_dict), tmp_dict.values()))

    @staticmethod
    def apply_inputs_mapping_for_all_lines(
        input_dict: Mapping[str, List[Mapping[str, Any]]],
        inputs_mapping: Mapping[str, str],
    ) -> List[Dict[str, Any]]:
        """Apply inputs mapping to all input lines.

        For example:
        input_dict = {
            'data': [{'question': 'q1', 'answer': 'ans1'}, {'question': 'q2', 'answer': 'ans2'}],
            'baseline': [{'answer': 'baseline_ans1'}, {'answer': 'baseline_ans2'}],
            'output': [{'answer': 'output_ans1', 'line_number': 0}, {'answer': 'output_ans2', 'line_number': 1}],
        }
        inputs_mapping: {
            "question": "${data.question}",  # Question from the data
            "groundtruth": "${data.answer}",  # Answer from the data
            "baseline": "${baseline.answer}",  # Answer from the baseline
            "deployment_name": "text-davinci-003",  # literal value
            "answer": "${output.answer}",  # Answer from the output
            "line_number": "${output.line_number}",  # Answer from the output
        }

        Returns:
        [{
            "question": "q1",
            "groundtruth": "ans1",
            "baseline": "baseline_ans1",
            "answer": "output_ans1",
            "deployment_name": "text-davinci-003",
            "line_number": 0,
        },
        {
            "question": "q2",
            "groundtruth": "ans2",
            "baseline": "baseline_ans2",
            "answer": "output_ans2",
            "deployment_name": "text-davinci-003",
            "line_number": 1,
        }]
        """
        if not inputs_mapping:
            if len(input_dict) == 1:
                # If there is only one input and no inputs_mapping, return the value of only input.
                return list(input_dict.values())[0]
            else:
                raise EmptyInputMappingError("inputs_mapping is empty and there are more than one input.")
        merged_list = FlowExecutor._merge_input_dicts_by_line(input_dict)

        result = [FlowExecutor.apply_inputs_mapping(item, inputs_mapping) for item in merged_list]
        return result

    def enable_streaming_for_llm_flow(self, stream_required: Callable[[], bool]):
        """Enable the LLM node that is connected to output to return streaming results controlled by stream_required.

        If the stream_required callback returns True, the LLM node will return a generator of strings.
        Otherwise, the LLM node will return a string.
        """
        for node in self._flow.nodes:
            if self._flow.is_llm_node(node) and self._flow.is_referenced_by_flow_output(node):
                self._tools_manager.wrap_tool(node.name, wrapper=inject_stream_options(stream_required))

    def ensure_flow_is_serializable(self):
        """Ensure that the flow is serializable.

        Some of the nodes may return a generator of strings to create streaming outputs.
        This is useful when the flow is deployed as a web service.
        However, in the interactive mode, the executor assumes that the node result is JSON serializable.

        This method adds a wrapper to each node in the flow
        to consume the streaming outputs and merge them into a string for executor usage.
        """
        for node in self._flow.nodes:
            self._tools_manager.wrap_tool(node.name, wrapper=ensure_node_result_is_serializable)


def inject_stream_options(should_stream: Callable[[], bool]):
    """Inject the stream options to the decorated function.

    AzureOpenAI.completion and AzureOpenAI.chat tools support both stream and non-stream mode.
    The stream mode is controlled by the "stream" parameter.
    """

    def stream_option_decorator(f):
        # We only wrap the function if it has a "stream" parameter
        signature = inspect.signature(f)
        if "stream" not in signature.parameters:
            return f

        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            kwargs = kwargs or {}
            kwargs.update(stream=should_stream())

            return f(*args, **kwargs)

        return wrapper

    return stream_option_decorator


def enable_streaming_for_llm_tool(f):
    """Enable the stream mode for LLM tools that supports it.

    AzureOpenAI.completion and AzureOpenAI.chat tools support both stream and non-stream mode.
    The stream mode is turned off by default. Use this wrapper to turn it on.
    """

    # We only wrap the function if it has a "stream" parameter
    signature = inspect.signature(f)
    if "stream" not in signature.parameters:
        return f

    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        kwargs = kwargs or {}
        kwargs.update(stream=True)

        return f(*args, **kwargs)

    return wrapper


def ensure_node_result_is_serializable(f):
    """Ensure the node result is serializable.

    Some of the nodes may return a generator of strings to create streaming outputs.
    This is useful when the flow is deployed as a web service.
    However, in the interactive mode, the executor assumes that the node result is JSON serializable.

    This wrapper ensures the node result is serializable
    by consuming the data from the generator and merging them into a string.
    """

    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        result = f(*args, **kwargs)
        if isinstance(result, GeneratorType):
            result = "".join(str(trunk) for trunk in result)
        return result

    return wrapper


class NodeReferenceError(UserErrorException):
    """Exception raised when node reference not found or unsupported"""

    def __init__(self, message, target=ErrorTarget.FLOW_EXECUTOR):
        msg = f"Invalid node reference: {message}"
        super().__init__(message=msg, target=target)


class UnsupportedReference(NodeReferenceError):
    pass


class InvalidReferenceProperty(NodeReferenceError):
    pass


class InputMappingError(UserErrorException):
    def __init__(self, message, target=ErrorTarget.FLOW_EXECUTOR):
        super().__init__(message=message, target=target)


class LineNumberNotAlign(InputMappingError):
    pass


class MappingSourceNotFound(InputMappingError):
    pass


class EmptyInputListError(InputMappingError):
    pass


class EmptyInputMappingError(InputMappingError):
    pass
