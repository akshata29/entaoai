from promptflow.exceptions import ErrorTarget, ValidationException


class ToolValidationError(ValidationException):
    def __init__(
        self,
        target: ErrorTarget = ErrorTarget.EXECUTOR,
        **kwargs,
    ):
        super().__init__(
            target=target,
            **kwargs,
        )


class ToolNotFoundInFlow(ToolValidationError):
    pass


class ToolTypeNotSupported(ToolValidationError):
    pass


class ToolLoadError(ToolValidationError):
    pass


class InvalidRequest(ValidationException):
    def __init__(
        self,
        target: ErrorTarget = ErrorTarget.EXECUTOR,
        **kwargs,
    ):
        super().__init__(
            target=target,
            **kwargs,
        )


class RequestTypeNotSupported(InvalidRequest):
    pass


class ConnectionNotFound(InvalidRequest):
    pass


class EmptyInputError(InvalidRequest):
    pass


class EvaluationFlowNotSupported(InvalidRequest):
    pass


class InvalidRunMode(InvalidRequest):
    pass


class InvalidBulkTestRequest(ValidationException):
    def __init__(
        self,
        target: ErrorTarget = ErrorTarget.EXECUTOR,
        **kwargs,
    ):
        super().__init__(
            target=target,
            **kwargs,
        )


class BulkTestIdNotFound(InvalidBulkTestRequest):
    pass


class BaselineVariantIdNotFound(InvalidBulkTestRequest):
    pass


class BaselineVariantInVariants(InvalidBulkTestRequest):
    pass


class EvaluationFlowRunIdNotFound(InvalidBulkTestRequest):
    pass


class VariantCountNotMatchWithRunCount(InvalidBulkTestRequest):
    pass


class InvalidEvalFlowRequest(ValidationException):
    def __init__(
        self,
        target: ErrorTarget = ErrorTarget.EXECUTOR,
        **kwargs,
    ):
        super().__init__(
            target=target,
            **kwargs,
        )


class VariantIdNotFound(InvalidEvalFlowRequest):
    pass


class DuplicateVariantId(InvalidEvalFlowRequest):
    pass


class InputNotFound(InvalidEvalFlowRequest):
    pass


class NumberOfInputsAndOutputsNotEqual(InvalidEvalFlowRequest):
    pass


class NoValidOutputLine(InvalidEvalFlowRequest):
    pass
