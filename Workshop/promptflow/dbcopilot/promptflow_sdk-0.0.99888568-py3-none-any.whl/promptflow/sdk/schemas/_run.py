# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import os.path

from dotenv import dotenv_values
from marshmallow import fields, post_load

from promptflow.sdk._constants import RunTypes
from promptflow.sdk.schemas._base import PatchedSchemaMeta, YamlFileSchema
from promptflow.sdk.schemas._fields import LocalPathField, StringTransformedEnum, UnionField


def _resolve_dot_env_file(data, **kwargs):
    """Resolve .env file to environment variables."""
    env_var = data.get("environment_variables", None)
    if env_var and os.path.exists(env_var):
        env_dict = dotenv_values(env_var)
        data["environment_variables"] = env_dict
    return data


class ConnectionOverrideSchema(metaclass=PatchedSchemaMeta):
    """Schema for connection override."""

    connection = fields.Str()
    deployment_name = fields.Str()


class RunSchema(YamlFileSchema):
    """Base schema for all run schemas."""

    name = fields.Str()
    flow = LocalPathField(required=True)
    environment_variables = UnionField(
        [
            fields.Dict(keys=fields.Str(), values=fields.Str()),
            # support load environment variables from .env file
            LocalPathField(),
        ]
    )
    connections = fields.Dict(keys=fields.Str(), values=fields.Dict(keys=fields.Str()))
    # inputs field
    data = LocalPathField(required=True)
    inputs_mapping = fields.Dict(keys=fields.Str, attribute="inputs_mapping")
    # runtime field, only available for cloud run
    runtime = fields.Str()


class BulkRunSchema(RunSchema):
    """Schema for bulk run."""

    type = StringTransformedEnum(allowed_values=RunTypes.BATCH, required=True)
    variant = fields.Str()

    @post_load
    def resolve_dot_env_file(self, data, **kwargs):
        return _resolve_dot_env_file(data, **kwargs)


class EvaluationRunSchema(RunSchema):
    """Schema for evaluation run."""

    type = StringTransformedEnum(allowed_values=RunTypes.EVALUATION, required=True)
    batch_run = fields.Str(required=True)

    @post_load
    def resolve_dot_env_file(self, data, **kwargs):
        return _resolve_dot_env_file(data, **kwargs)


class PairwiseEvaluationRunSchema(RunSchema):
    """Schema for pairwise evaluation run."""

    type = StringTransformedEnum(allowed_values=RunTypes.PAIRWISE_EVALUATE, required=True)

    @post_load
    def resolve_dot_env_file(self, data, **kwargs):
        return _resolve_dot_env_file(data, **kwargs)
