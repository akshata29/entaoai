# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from marshmallow import fields

from promptflow.sdk._utils import snake_to_camel
from promptflow.sdk.schemas._base import YamlFileSchema
from promptflow.sdk.schemas._fields import StringTransformedEnum

type_dict = {
    "azure_open_ai": "AzureOpenAI",
    "open_ai": "OpenAI",
}


def casing_type(x):
    if x in type_dict:
        return type_dict.get(x)
    return snake_to_camel(x)


class ConnectionSchema(YamlFileSchema):
    name = fields.Str(attribute="name")
    module = fields.Str(default="promptflow.connections")
    created_date = fields.Str(dump_only=True)
    last_modified_date = fields.Str(dump_only=True)
    expiry_time = fields.Str(dump_only=True)


class AzureOpenAIConnectionSchema(ConnectionSchema):
    type = StringTransformedEnum(allowed_values="AzureOpenAI", casing_transform=casing_type, required=True)
    api_key = fields.Str(required=True)
    api_base = fields.Str(required=True)
    api_type = fields.Str(default="azure")
    api_version = fields.Str(default="2023-03-15-preview")


class OpenAIConnectionSchema(ConnectionSchema):
    type = StringTransformedEnum(allowed_values="OpenAI", casing_transform=casing_type, required=True)
    api_key = fields.Str(required=True)
    organization = fields.Str()


class CognitiveSearchConnectionSchema(ConnectionSchema):
    type = StringTransformedEnum(allowed_values="CognitiveSearch", casing_transform=casing_type, required=True)
    api_key = fields.Str(required=True)
    api_base = fields.Str(required=True)
    api_version = fields.Str(default="2023-07-01-Preview")


class SerpConnectionSchema(ConnectionSchema):
    type = StringTransformedEnum(allowed_values="Serp", casing_transform=casing_type, required=True)
    api_key = fields.Str(required=True)


class AzureContentSafetyConnectionSchema(ConnectionSchema):
    type = StringTransformedEnum(allowed_values="AzureContentSafety", casing_transform=casing_type, required=True)
    api_key = fields.Str(required=True)
    endpoint = fields.Str(required=True)
    api_version = fields.Str(default="2023-04-30-preview")


class CustomConnectionSchema(ConnectionSchema):
    type = StringTransformedEnum(allowed_values="Custom", casing_transform=casing_type, required=True)
    configs = fields.Dict(keys=fields.Str(), values=fields.Str())
    # Secrets is a must-have field for CustomConnection
    secrets = fields.Dict(keys=fields.Str(), values=fields.Str())
