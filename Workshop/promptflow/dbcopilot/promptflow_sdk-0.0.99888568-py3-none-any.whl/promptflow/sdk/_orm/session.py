# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import multiprocessing
import threading
from contextlib import contextmanager
from os import PathLike
from pathlib import Path
from typing import Union

from sqlalchemy import create_engine, inspect
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session, sessionmaker

from promptflow.sdk._constants import CONNECTION_TABLE_NAME, LOCAL_MGMT_DB_PATH, RUN_INFO_TABLENAME
from promptflow.sdk._utils import use_customized_encryption_key

session_maker = None
lock = threading.Lock()
create_table_lock = multiprocessing.Lock()


def mgmt_db_session() -> Session:
    global session_maker
    global lock
    if session_maker is not None:
        return session_maker()
    lock.acquire()
    # use try-finally to always release lock
    try:
        if session_maker is not None:
            return session_maker()
        if not LOCAL_MGMT_DB_PATH.parent.is_dir():
            LOCAL_MGMT_DB_PATH.parent.mkdir(parents=True, exist_ok=True)

        engine = create_engine(f"sqlite:///{str(LOCAL_MGMT_DB_PATH)}")

        from promptflow.sdk._orm import Connection, RunInfo

        create_table_if_not_exists(engine, RUN_INFO_TABLENAME, RunInfo)
        create_table_if_not_exists(engine, CONNECTION_TABLE_NAME, Connection)

        session_maker = sessionmaker(bind=engine)
    finally:
        lock.release()

    return session_maker()


def create_table_if_not_exists(engine, table_name, orm_class) -> None:
    if inspect(engine).has_table(table_name):
        return
    create_table_lock.acquire()
    try:
        if inspect(engine).has_table(table_name):
            return
        orm_class.metadata.create_all(engine)
    except OperationalError as e:
        # only ignore error if table already exists
        expected_error_message = f"table {table_name} already exists"
        if expected_error_message not in str(e):
            raise
    finally:
        create_table_lock.release()


@contextmanager
def mgmt_db_rebase(mgmt_db_path: Union[Path, PathLike, str], customized_encryption_key: str = None) -> Session:
    """
    This function will change the constant LOCAL_MGMT_DB_PATH to the new path so very dangerous.
    It is created for pf flow export only and need to be removed in further version.
    """
    global session_maker
    global LOCAL_MGMT_DB_PATH

    origin_local_db_path = LOCAL_MGMT_DB_PATH

    LOCAL_MGMT_DB_PATH = mgmt_db_path
    session_maker = None

    if customized_encryption_key:
        with use_customized_encryption_key(customized_encryption_key):
            yield
    else:
        yield

    LOCAL_MGMT_DB_PATH = origin_local_db_path
    session_maker = None
