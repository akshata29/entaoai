# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import json
from enum import Enum
from typing import Dict, List, Optional

from sqlalchemy import TEXT, Boolean, Column
from sqlalchemy.ext.declarative import declarative_base

from promptflow.sdk._constants import RUN_INFO_TABLENAME, ListViewType

from .session import mgmt_db_session

Base = declarative_base()


class RunInfo(Base):
    __tablename__ = RUN_INFO_TABLENAME

    name = Column(TEXT, primary_key=True)
    type = Column(TEXT, nullable=False)
    created_on = Column(TEXT, nullable=False)  # ISO8601("YYYY-MM-DD HH:MM:SS.SSS"), string
    status = Column(TEXT, nullable=False)
    display_name = Column(TEXT, nullable=False)  # can be edited by users
    description = Column(TEXT)  # updated by users
    tags = Column(TEXT)  # updated by users, json(list of jsons) string
    # properties: flow path, output path..., json string
    # as we can parse and get all informations from parsing the YAML in memory,
    # we don't need to store any extra information in the database at all;
    # however, if there is any hot fields, we can store them here additionally.
    properties = Column(TEXT)
    archived = Column(Boolean, default=False)

    def dump(self) -> None:
        with mgmt_db_session() as session:
            session.add(self)
            session.commit()

    def archive(self) -> None:
        if self.archived is True:
            return
        self.archived = True
        with mgmt_db_session() as session:
            session.query(RunInfo).filter(RunInfo.name == self.name).update({"archived": self.archived})
            session.commit()

    def restore(self) -> None:
        if self.archived is False:
            return
        self.archived = False
        with mgmt_db_session() as session:
            session.query(RunInfo).filter(RunInfo.name == self.name).update({"archived": self.archived})
            session.commit()

    def update(
        self,
        *,
        status: Optional[str] = None,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        update_dict = {}
        if status is not None:
            self.status = status
            update_dict["status"] = self.status
        if display_name is not None:
            self.display_name = display_name
            update_dict["display_name"] = self.display_name
        if description is not None:
            self.description = description
            update_dict["description"] = self.description
        if tags is not None:
            self.tags = json.dumps(tags)
            update_dict["tags"] = self.tags
        with mgmt_db_session() as session:
            session.query(RunInfo).filter(RunInfo.name == self.name).update(update_dict)
            session.commit()

    @staticmethod
    def get(name: str) -> "RunInfo":
        with mgmt_db_session() as session:
            run_info = session.query(RunInfo).filter(RunInfo.name == name).first()
        if run_info is None:
            raise ValueError(f"Run {name} is not found.")
        return run_info

    @staticmethod
    def list(max_results: Optional[int], list_view_type: ListViewType) -> List["RunInfo"]:
        with mgmt_db_session() as session:
            basic_statement = session.query(RunInfo)
            # filter by archived
            list_view_type = list_view_type.value if isinstance(list_view_type, Enum) else list_view_type
            if list_view_type == ListViewType.ACTIVE_ONLY.value:
                basic_statement = basic_statement.filter(RunInfo.archived == False)  # noqa: E712
            elif list_view_type == ListViewType.ARCHIVED_ONLY.value:
                basic_statement = basic_statement.filter(RunInfo.archived == True)  # noqa: E712

            if isinstance(max_results, int):
                return [run_info for run_info in basic_statement.limit(max_results)]
            else:
                return [run_info for run_info in basic_statement.all()]
