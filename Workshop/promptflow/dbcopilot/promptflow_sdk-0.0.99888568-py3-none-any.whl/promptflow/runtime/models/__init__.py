# TODO: Remove this folder after new swagger generated.
# flake8: noqa
from ._models import (
    ApiKeyAuthTypeWorkspaceConnectionProperties,
    CustomKeysAuthTypeWorkspaceConnectionProperties,
    SystemData,
    WorkspaceConnectionApiKey,
    WorkspaceConnectionCustomKeys,
    WorkspaceConnectionPropertiesV2,
    WorkspaceConnectionPropertiesV2BasicResource,
)
