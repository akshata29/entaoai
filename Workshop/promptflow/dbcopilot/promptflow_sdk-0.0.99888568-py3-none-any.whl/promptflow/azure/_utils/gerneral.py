def is_arm_id(obj) -> bool:
    return isinstance(obj, str) and obj.startswith("azureml://")

