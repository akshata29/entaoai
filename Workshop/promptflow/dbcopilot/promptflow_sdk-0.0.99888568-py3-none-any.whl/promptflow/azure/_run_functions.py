# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import os
import uuid
from os import PathLike
from pathlib import Path
from typing import Union, AnyStr, IO

from promptflow.azure._configuration import _get_run_operations
from promptflow.sdk._load_functions import load_run
from promptflow.sdk.entities import BulkRun, EvaluationRun, Run


def _create_run(run: Union[BulkRun, EvaluationRun], **kwargs):
    run_ops = _get_run_operations()
    return run_ops.create_or_update(run=run, **kwargs)


def run_batch(
        flow: Union[str, PathLike],
        *,
        data: Union[str, PathLike],
        inputs_mapping: dict = None,
        variant: str = None,
        **kwargs,
) -> BulkRun:
    """Run single variant of a flow.

    :param flow: path to flow directory to run
    :param data: data inputs for flow run.
    :param inputs_mapping: define a data flow logic to map input data, support:
        from data: data.col1:
        Example:
            {"question": "${data.question}", "context": "${data.context}"}
    :param variant: Node & variant name in format of ${node_name.variant_name}, will use default variant
        if not specified.
    :return: bulk run info.
    """
    if not os.path.exists(flow):
        raise FileNotFoundError(f"flow path {flow} does not exist")
    if not os.path.exists(data):
        raise FileNotFoundError(f"data path {data} does not exist")

    bulk_run = BulkRun(
        name=str(uuid.uuid4()),
        data=data,
        inputs_mapping=inputs_mapping,
        flow=Path(flow),
        variant=variant,
        skip_dump=True,
    )
    return _create_run(run=bulk_run, **kwargs)


def run_eval(
    flow: Union[str, PathLike],
    *,
    data: Union[str, PathLike],
    batch_run: Union[str, Run],
    inputs_mapping: dict = None,
    **kwargs,
) -> EvaluationRun:
    """Run evaluation of a flow.

    :param flow: path to flow directory to run evaluation
    :param data: pointer to test data (of variant bulk runs) for eval runs
    :param inputs_mapping: define a data flow logic to map input data, support:
        from data: data.col1:
        from variant:
            [0].col1, [1].col2: if need different col from variant run data
            variant.output.col1: if all upstream runs has col1
        Example:
            {"ground_truth": "${data.answer}", "prediction": "${batch_run.outputs.answer}"}
    :param batch_run:
        batch run id or batch run
        keep lineage between current run and variant runs
        batch outputs can be referenced as ${batch_run.outputs.col_name} in inputs_mapping
    :return: evaluation run info.
    """
    if not os.path.exists(flow):
        raise FileNotFoundError(f"flow path {flow} does not exist")
    if not os.path.exists(data):
        raise FileNotFoundError(f"data path {data} does not exist")

    eval_run = EvaluationRun(
        # TODO(2523341): default to flow folder name + timestamp
        name=str(uuid.uuid4()),
        data=data,
        inputs_mapping=inputs_mapping,
        batch_run=batch_run,
        flow=Path(flow),
        skip_dump=True
    )
    return _create_run(run=eval_run, **kwargs)
