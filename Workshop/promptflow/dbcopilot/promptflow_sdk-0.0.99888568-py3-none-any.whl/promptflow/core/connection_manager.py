import copy
import json
import os
from dataclasses import fields, is_dataclass
from pathlib import Path
from typing import Any, Dict, List

from promptflow._constants import CONNECTION_NAME_PROPERTY, CONNECTION_SECRET_KEYS, PROMPTFLOW_CONNECTIONS
from promptflow.contracts.types import Secret
from promptflow.utils.utils import try_import


class ConnectionManager:
    """This class will be used for construction mode to run flow locally. Do not include it into tool code."""

    instance = None

    def __init__(self, _dict: Dict[str, dict] = None):
        if _dict is None:
            # !!! Important !!!: Do not leverage this environment variable in any production code, this is test only.
            if PROMPTFLOW_CONNECTIONS not in os.environ:
                raise ValueError(f"Required environment variable {PROMPTFLOW_CONNECTIONS!r} not set.")
            connection_path = Path(os.environ[PROMPTFLOW_CONNECTIONS]).resolve().absolute()
            if not connection_path.exists():
                raise ValueError(f"Connection file not exists. Path {connection_path.as_posix()}.")
            _dict = json.loads(open(connection_path).read())
        self._connections_dict = _dict
        self._connections = self._build_connections(_dict)

    @classmethod
    def _build_connections(cls, _dict: Dict[str, dict]):
        """Build connection dict."""
        from promptflow.core.tools_manager import connections as cls_mapping

        cls.import_requisites(_dict)
        connections = {}  # key to connection object
        for key, connection_dict in _dict.items():
            typ = connection_dict.get("type")
            if typ not in cls_mapping:
                raise ValueError(f"Unknown connection {key!r} type {typ!r}, supported are {cls_mapping.keys()}.")
            value = connection_dict.get("value", {})
            connection_class = cls_mapping[typ]

            from promptflow.connections import CustomConnection

            if connection_class is CustomConnection:
                connection_value = connection_class(**value)
                connection_value.__secret_keys = connection_dict.get("secret_keys", [])
                # Note: CustomConnection definition can not be got, secret keys will be provided in connection dict.
                setattr(connection_value, CONNECTION_SECRET_KEYS, connection_dict.get("secret_keys", []))
            else:
                # Note: Ignore non exists key, as for open ai connection,
                # 'organization' is missing in dataclass definition.
                cls_fields = {f.name: f for f in fields(connection_class)} if is_dataclass(connection_class) else {}
                connection_value = connection_class(**{k: v for k, v in value.items() if k in cls_fields})
                setattr(
                    connection_value,
                    CONNECTION_SECRET_KEYS,
                    [f.name for f in cls_fields.values() if f.type == Secret],
                )
            # Use this hack to make sure serialization works
            setattr(connection_value, CONNECTION_NAME_PROPERTY, key)
            connections[key] = connection_value
        return connections

    @classmethod
    def init_from_env(cls):
        return ConnectionManager()

    def get(self, connection_name: str) -> Any:
        if not isinstance(connection_name, str):
            return None
        return self._connections.get(connection_name)

    def get_secret_list(self) -> List[str]:
        def secrets():
            for connection in self._connections.values():
                secret_keys = getattr(connection, CONNECTION_SECRET_KEYS, [])
                for secret_key in secret_keys:
                    yield getattr(connection, secret_key)

        return list(secrets())

    @classmethod
    def import_requisites(cls, _dict: Dict[str, dict]):
        """Import connection required modules."""
        modules = set()
        for key, connection_dict in _dict.items():
            module = connection_dict.get("module")
            if module:
                modules.add(module)
        for module in modules:
            try_import(module, f"Import connection module {module!r} failed.")

    @staticmethod
    def is_legacy_connections(_dict: Dict[str, dict]):
        """Detect if is legacy connections. Legacy connections dict doesn't have module and type.
        So import requisites can not be performed. Only request from MT will hit this.

        Legacy connection example: {"aoai_config": {"api_key": "..."}}
        """
        has_module = any(isinstance(v, dict) and "module" in v for k, v in _dict.items())
        return not has_module

    def to_connections_dict(self) -> dict:
        """Get all connections and reformat to key-values format."""
        # Value returned: {"aoai_config": {"api_key": "..."}}
        return copy.deepcopy(self._connections_dict)
