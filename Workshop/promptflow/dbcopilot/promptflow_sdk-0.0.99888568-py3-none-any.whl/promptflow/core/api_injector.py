import functools
import inspect
from datetime import datetime

import openai

from promptflow.contracts.trace import Trace, TraceType

from .tracer import Tracer


def inject_function(args_to_ignore=None, trace_type=TraceType.LLM):
    args_to_ignore = args_to_ignore or []
    args_to_ignore = set(args_to_ignore)

    def wrapper(f):
        sig = inspect.signature(f).parameters

        @functools.wraps(f)
        def wrapped_method(*args, **kwargs):
            if not Tracer.active():
                return f(*args, **kwargs)

            all_kwargs = {**{k: v for k, v in zip(sig.keys(), args)}, **kwargs}
            for key in args_to_ignore:
                all_kwargs.pop(key, None)
            name = f.__qualname__ if not f.__module__ else f.__module__ + "." + f.__qualname__
            trace = Trace(
                name=name,
                type=trace_type,
                inputs=all_kwargs,
                start_time=datetime.utcnow().timestamp(),
            )
            Tracer.push(trace)
            try:
                result = f(*args, **kwargs)
            except Exception as ex:
                Tracer.pop(error=ex)
                raise
            else:
                Tracer.pop(result)
            return result

        return wrapped_method

    return wrapper


def inject_operation_headers(f):
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        from promptflow.core.operation_context import OperationContext

        # Inject headers from operation context, overwrite injected header with headers from kwargs.
        injected_headers = OperationContext.get_instance().get_http_headers()
        original_headers = kwargs.get("headers")
        if original_headers and isinstance(original_headers, dict):
            injected_headers.update(original_headers)
        kwargs.update(headers=injected_headers)

        return f(*args, **kwargs)

    return wrapper


def inject(f):
    wrapper_fun = inject_operation_headers((inject_function(["api_key", "headers"])(f)))
    wrapper_fun._original = f
    return wrapper_fun


def inject_openai_api():
    if not hasattr(openai.Completion.create, "_original"):
        openai.Completion.create = inject(openai.Completion.create)

    if not hasattr(openai.ChatCompletion.create, "_original"):
        openai.ChatCompletion.create = inject(openai.ChatCompletion.create)

    if not hasattr(openai.Embedding.create, "_original"):
        openai.Embedding.create = inject(openai.Embedding.create)


def recover_openai_api():
    if hasattr(openai.Completion.create, "_original"):
        openai.Completion.create = openai.Completion.create._original

    if hasattr(openai.ChatCompletion.create, "_original"):
        openai.ChatCompletion.create = openai.ChatCompletion.create._original

    if hasattr(openai.Embedding.create, "_original"):
        openai.Embedding.create = openai.Embedding.create._original
