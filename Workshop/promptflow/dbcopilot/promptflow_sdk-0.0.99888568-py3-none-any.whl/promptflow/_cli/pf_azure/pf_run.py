# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import argparse
import json
import uuid
from typing import Optional

from tabulate import tabulate

from promptflow._cli.pf_run import _parse_kv_pair, add_run_create
from promptflow._cli.utils import _set_workspace_argument_for_subparsers, get_client_for_cli
from promptflow.azure import PFClient
from promptflow.sdk._constants import MAX_LIST_CLI_RESULTS, MAX_SHOW_DETAILS_RESULTS, ListViewType
from promptflow.sdk._load_functions import load_run
from promptflow.sdk.entities import Run


def add_parser_run(subparsers):
    """Add run parser to the pfazure subparsers."""
    run_parser = subparsers.add_parser(
        "run", description="A CLI tool to manage cloud runs for prompt flow.", help="Manage promptflow runs."
    )
    subparsers = run_parser.add_subparsers()

    add_run_create_cloud(subparsers)
    add_parser_run_list(subparsers)
    add_parser_run_stream(subparsers)
    add_parser_run_show(subparsers)
    add_parser_run_show_details(subparsers)
    add_parser_run_show_metrics(subparsers)
    # add_parser_run_cancel(subparsers)
    add_parser_run_visualize(subparsers)
    # add_parser_run_archive(subparsers)
    # add_parser_run_restore(subparsers)
    # add_parser_run_update(subparsers)
    run_parser.set_defaults(action="run")


def add_run_create_cloud(subparsers):
    parser = add_run_create(subparsers)
    _set_workspace_argument_for_subparsers(parser)
    parser.add_argument("--runtime", type=str, help=argparse.SUPPRESS)


def add_parser_run_list(subparsers):
    """Add run list parser to the pfazure subparsers."""
    run_list_parser = subparsers.add_parser(
        "list", description="A CLI tool to List all runs.", help="List runs in a workspace."
    )
    _set_workspace_argument_for_subparsers(run_list_parser)
    run_list_parser.add_argument(
        "-r",
        "--max-results",
        dest="max_results",
        type=int,
        default=MAX_LIST_CLI_RESULTS,
        help=f"Max number of results to return. Default is {MAX_LIST_CLI_RESULTS}, 100 at most.",
    )
    run_list_parser.add_argument(
        "--archived-only",
        action="store_true",
        help="List archived runs only.",
    )
    run_list_parser.add_argument(
        "--include-archived",
        action="store_true",
        help="List archived runs and active runs.",
    )
    run_list_parser.set_defaults(sub_action="list")


def add_parser_run_stream(subparsers):
    """Add run stream parser to the pfazure subparsers."""
    run_stream_parser = subparsers.add_parser(
        "stream", description="A CLI tool to stream run logs to the console.", help="Stream run logs to the console."
    )
    _set_workspace_argument_for_subparsers(run_stream_parser)
    run_stream_parser.add_argument("-n", "--name", type=str, required=True, help="The run name to stream.")
    run_stream_parser.set_defaults(sub_action="stream")


def add_parser_run_show(subparsers):
    """Add run show parser to the pfazure subparsers."""
    run_show_parser = subparsers.add_parser("show", description="A CLI tool to show a run.", help="Show a run.")
    _set_workspace_argument_for_subparsers(run_show_parser)
    run_show_parser.add_argument("-n", "--name", type=str, required=True, help="The run name to show.")
    run_show_parser.set_defaults(sub_action="show")


def add_parser_run_show_details(subparsers):
    """Add run show details parser to the pfazure subparsers."""
    run_show_details_parser = subparsers.add_parser(
        "show-details", description="A CLI tool to show a run details.", help="Show a run details."
    )
    _set_workspace_argument_for_subparsers(run_show_details_parser)
    run_show_details_parser.add_argument("-n", "--name", type=str, required=True, help="The run name to show details.")
    run_show_details_parser.add_argument(
        "-r",
        "--max-results",
        dest="max_results",
        type=int,
        default=MAX_SHOW_DETAILS_RESULTS,
        help=f"Number of lines to show. Default is {MAX_SHOW_DETAILS_RESULTS}.",
    )
    run_show_details_parser.set_defaults(sub_action="show-details")


def add_parser_run_show_metrics(subparsers):
    """Add run show metrics parser to the pfazure subparsers."""
    run_show_metrics_parser = subparsers.add_parser(
        "show-metrics", description="A CLI tool to show run metrics.", help="Show run metrics."
    )
    _set_workspace_argument_for_subparsers(run_show_metrics_parser)
    run_show_metrics_parser.add_argument("-n", "--name", type=str, required=True, help="The run name to show metrics.")
    run_show_metrics_parser.set_defaults(sub_action="show-metrics")


def add_parser_run_cancel(subparsers):
    """Add run cancel parser to the pfazure subparsers."""
    run_cancel_parser = subparsers.add_parser("cancel", description="A CLI tool to cancel a run.", help="Cancel a run.")
    _set_workspace_argument_for_subparsers(run_cancel_parser)
    run_cancel_parser.add_argument("-n", "--name", type=str, required=True, help="The run name to cancel.")
    run_cancel_parser.set_defaults(sub_action="cancel")


def add_parser_run_visualize(subparsers):
    """Add run visualize parser to the pfazure subparsers."""
    run_visualize_parser = subparsers.add_parser(
        "visualize", description="A CLI tool to visualize a run.", help="Visualize a run."
    )
    _set_workspace_argument_for_subparsers(run_visualize_parser)
    run_visualize_parser.add_argument(
        "-n", "--names", type=str, required=True, help="Name of the runs, comma separated."
    )
    run_visualize_parser.add_argument("--html-path", type=str, default=None, help=argparse.SUPPRESS)
    run_visualize_parser.set_defaults(sub_action="visualize")


def add_parser_run_archive(subparsers):
    """Add run archive parser to the pfazure subparsers."""
    run_archive_parser = subparsers.add_parser(
        "archive", description="A CLI tool to archive a run.", help="Archive a run."
    )
    _set_workspace_argument_for_subparsers(run_archive_parser)
    run_archive_parser.add_argument("-n", "--name", type=str, required=True, help="The run name to archive.")
    run_archive_parser.set_defaults(sub_action="archive")


def add_parser_run_restore(subparsers):
    """Add run restore parser to the pfazure subparsers."""
    run_restore_parser = subparsers.add_parser(
        "restore", description="A CLI tool to restore a run.", help="Restore a run."
    )
    _set_workspace_argument_for_subparsers(run_restore_parser)
    run_restore_parser.add_argument("-n", "--name", type=str, required=True, help="The run name to restore.")
    run_restore_parser.set_defaults(sub_action="restore")


def add_parser_run_update(subparsers):
    """Add run update parser to the pfazure subparsers."""
    run_update_parser = subparsers.add_parser(
        "update",
        description="A CLI tool to update a run.",
        help="Update a run.",
    )
    _set_workspace_argument_for_subparsers(run_update_parser)
    run_update_parser.add_argument("-n", "--name", type=str, required=True, help="The run name to update.")
    run_update_parser.set_defaults(sub_action="update")


def dispatch_run_commands(args: argparse.Namespace):
    if args.sub_action == "create":
        create_run(
            subscription_id=args.subscription,
            resource_group=args.resource_group,
            workspace_name=args.workspace_name,
            file=args.file,
            type=args.type,
            flow=args.flow,
            data=args.data,
            inputs_mapping=args.inputs_mapping,
            variant=args.variant,
            name=args.name,
            batch_run=args.batch_run,
            stream=args.stream,
            runtime=args.runtime,
        )
    elif args.sub_action == "list":
        list_runs(
            args.subscription,
            args.resource_group,
            args.workspace_name,
            args.max_results,
            args.archived_only,
            args.include_archived,
        )
    elif args.sub_action == "show":
        show_run(args.subscription, args.resource_group, args.workspace_name, args.name)
    elif args.sub_action == "show-details":
        show_run_details(args.subscription, args.resource_group, args.workspace_name, args.name, args.max_results)
    elif args.sub_action == "show-metrics":
        show_metrics(args.subscription, args.resource_group, args.workspace_name, args.name)
    elif args.sub_action == "stream":
        stream_run(args.subscription, args.resource_group, args.workspace_name, args.name)
    elif args.sub_action == "visualize":
        visualize(args.subscription, args.resource_group, args.workspace_name, args.names, args.html_path)


def _get_azure_pf_client(subscription_id, resource_group, workspace_name):
    ml_client = get_client_for_cli(
        subscription_id=subscription_id, resource_group_name=resource_group, workspace_name=workspace_name
    )
    return PFClient(ml_client)


def list_runs(subscription_id, resource_group, workspace_name, max_results, archived_only, include_archived):
    """List all runs from cloud."""
    if max_results < 1:
        raise ValueError(f"'max_results' must be a positive integer, got {max_results!r}")

    # Default list_view_type is ACTIVE_ONLY
    if archived_only and include_archived:
        raise ValueError("Cannot specify both 'archived_only' and 'include_archived'")
    list_view_type = ListViewType.ACTIVE_ONLY
    if archived_only:
        list_view_type = ListViewType.ARCHIVED_ONLY
    if include_archived:
        list_view_type = ListViewType.ALL

    pf = _get_azure_pf_client(subscription_id, resource_group, workspace_name)
    runs = pf.runs.list(max_results=max_results, list_view_type=list_view_type)
    founded_run_count = len(runs)
    print(f"Found {founded_run_count} runs.")
    if founded_run_count > 0:
        print(f"============== Display {founded_run_count} runs ==============")
        for run in runs:
            print(json.dumps(run._to_dict(), indent=4))
            print("=====================================================")
    return runs


def show_run(subscription_id, resource_group, workspace_name, flow_run_id):
    """Show a run from cloud."""
    pf = _get_azure_pf_client(subscription_id, resource_group, workspace_name)
    run = pf.runs.get(run=flow_run_id)
    print(json.dumps(run._to_dict(), indent=4))


def show_run_details(subscription_id, resource_group, workspace_name, flow_run_id, max_results):
    """Show a run details from cloud."""
    pf = _get_azure_pf_client(subscription_id, resource_group, workspace_name)
    details = pf.runs.get_details(run=flow_run_id)
    print(tabulate(details.head(max_results), headers="keys", tablefmt="psql"))


def show_metrics(subscription_id, resource_group, workspace_name, flow_run_id):
    """Show run metrics from cloud."""
    pf = _get_azure_pf_client(subscription_id, resource_group, workspace_name)
    metrics = pf.runs.get_metrics(run=flow_run_id)
    print(json.dumps(metrics, indent=4))


# TODO: reuse _cli/pf_run.create_run
def create_run(
    subscription_id,
    resource_group,
    workspace_name,
    file=None,
    type=None,
    flow=None,
    data=None,
    inputs_mapping=None,
    variant=None,
    batch_run=None,
    name=None,
    runtime=None,
    stream=None,
):
    if file:
        params_override = []
        for param_key, param in {
            "name": name,
            "type": type,
            "flow": flow,
            "variant": variant,
            "data": data,
            "inputs_mapping": inputs_mapping,
            "batch_run": batch_run,
        }.items():
            if not param:
                continue
            params_override.append({param_key: param})

        run = load_run(source=file, params_override=params_override)
    elif not (type is not None and flow is not None and data is not None):
        raise ValueError("Must specify --type, --flow, and --data when not using --file.")
    else:
        if inputs_mapping:
            inputs_mapping = _parse_kv_pair(inputs_mapping)

        run_data = {
            "name": name or str(uuid.uuid4()),
            "type": type,
            "flow": flow,
            "data": data,
            "inputs_mapping": inputs_mapping,
            "batch_run": batch_run,
            "variant": variant,
        }
        # remove empty fields
        run_data = {k: v for k, v in run_data.items() if v is not None}

        run = Run._load(data=run_data)
    pf = _get_azure_pf_client(subscription_id, resource_group, workspace_name)
    run = pf.runs.create_or_update(run=run, runtime=runtime)
    print(json.dumps(run._to_dict(), indent=4))


def stream_run(subscription_id, resource_group, workspace_name, flow_run_id):
    """Stream run logs from cloud."""
    pf = _get_azure_pf_client(subscription_id, resource_group, workspace_name)
    pf.runs.stream(flow_run_id)


def visualize(
    subscription_id: str,
    resource_group: str,
    workspace_name: str,
    names: str,
    html_path: Optional[str] = None,
):
    run_names = names.split(",")
    pf = _get_azure_pf_client(subscription_id, resource_group, workspace_name)
    pf.runs.visualize(run_names, html_path=html_path)
