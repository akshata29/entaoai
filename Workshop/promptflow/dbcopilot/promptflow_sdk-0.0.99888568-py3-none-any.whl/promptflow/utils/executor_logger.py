import re
import logging
import sys
from contextlib import contextmanager
from contextvars import ContextVar
from opencensus.ext.azure.log_exporter import AzureLogHandler
from typing import List, Optional, Dict

from promptflow.contracts.run_mode import RunMode
from promptflow.contracts.runtime import SubmitFlowRequest
from promptflow._constants import PromptflowEdition
from promptflow.utils.credential_scrubber import CredentialScrubber, get_credential_list_from_request


# The maximum length of logger name is 18 ("promptflow-runtime").
# The maximum digit length of process id is 5. Fix the field width to 7.
# So fix the length of these fields in the formatter.
# May need to change if logger name/process id length changes.
LOG_FORMAT = '%(asctime)s %(process)7d %(name)-18s %(levelname)-8s %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S %z'


class CredentialScrubberFormatter(logging.Formatter):
    """Formatter that scrubs credentials in logs."""

    def __init__(self, scrub_customer_content, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._default_scrubber = CredentialScrubber()
        self._context_var = ContextVar('credential_scrubber', default=None)
        self._scrub_customer_content = scrub_customer_content

    @property
    def credential_scrubber(self):
        credential_scrubber = self._context_var.get()
        if credential_scrubber:
            return credential_scrubber
        return self._default_scrubber

    def set_credential_list(self, credential_list: List[str]):
        """Set credential list, which will be scrubbed in logs."""
        credential_scrubber = CredentialScrubber()
        for c in credential_list:
            credential_scrubber.add_str(c)
        self._context_var.set(credential_scrubber)

    def clear(self):
        """Clear context variable."""
        self._context_var.set(None)

    def format(self, record):
        """Override logging.Formatter's format method and remove credentials from log."""
        s: str = super().format(record)

        if self._scrub_customer_content:
            # Scrub everything after traceback, because it might contain customer information.
            s = re.sub(r"(?<=traceback)[\s\S]*", CredentialScrubber.PLACE_HOLDER, s, flags=re.IGNORECASE)

        if hasattr(record, 'customer_content'):
            if self._scrub_customer_content:
                s = s.format(customer_content=CredentialScrubber.PLACE_HOLDER)
            else:
                s = s.format(customer_content=record.customer_content)
        return self.credential_scrubber.scrub(s)

    def formatException(self, ei) -> str:
        """Override logging.Formatter's formatException method.

        Only return exception type.
        """
        if self._scrub_customer_content:
            return f"Exception type: {ei[0]}"
        return super().formatException(ei)

    def formatStack(self, stack_info):
        """Override logging.Formatter's formatStack method."""
        if self._scrub_customer_content:
            return ""
        return super().formatStack(stack_info)


class ExecutionLogHandler(logging.Handler):
    """Write compliant log to a local file (community edition) or a blob file (enterprise edition)."""
    def __init__(self):
        super().__init__()
        self._edition = None
        # Use context variable to store stream handler for thread safety.
        self._context_var = ContextVar('stream_handler', default=None)
        # Use formatter to scrub credentials in log message, exception and stack trace.
        self._formatter = CredentialScrubberFormatter(
            scrub_customer_content=False,
            fmt=LOG_FORMAT,
            datefmt=DATETIME_FORMAT)

    @property
    def edition(self):
        return self._edition

    @edition.setter
    def edition(self, edition: PromptflowEdition):
        self._edition = edition

    @property
    def is_log_path_set(self):
        return self._context_var.get() is not None

    def set_log_path(self, log_path: Optional[str]):
        """Set context variable stream_handler.

        For community edition, stream_handler is a FileHandler, which writes logs to local file.
        For enterprise edition, stream_handler is a StreamHandler, which writes logs to blob file.
        """
        if not log_path:
            return
        stream_handler = None
        if self.edition == PromptflowEdition.COMMUNITY:
            stream_handler = logging.FileHandler(log_path)
        elif self.edition == PromptflowEdition.ENTERPRISE:
            from promptflow.utils.blob_utils import BlobStream
            stream_handler = logging.StreamHandler(BlobStream(log_path))

        if stream_handler:
            stream_handler.setFormatter(self._formatter)
            self._context_var.set(stream_handler)

    def set_credential_list(self, credential_list: List[str]):
        """Set credential list, which will be scrubbed in logs emitted by handler."""
        self._formatter.set_credential_list(credential_list)

    def emit(self, record):
        """Override logging.Handler's emit method."""
        stream_handler = self._context_var.get()
        if stream_handler is None:
            return

        stream_handler.emit(record)

    def clear(self):
        """Close file/stream handler and clear context variable."""
        stream_handler = self._context_var.get()
        if stream_handler:
            stream_handler.close()
        self._context_var.set(None)

        # Clear formatter.
        self._formatter.clear()


class TelemetryLogHandler(logging.Handler):
    """Write compliant log (no customer content) to app insights."""
    FORMAT = "%(message)s"
    CONNECTION_STRING = ""

    def __init__(self):
        super().__init__()
        self._edition = None
        self._handler = None
        self._context = ContextVar('request_context', default=None)
        self._formatter = CredentialScrubberFormatter(
            scrub_customer_content=True,  # Telemetry log should not contain customer content.
            fmt=self.FORMAT)

    @property
    def edition(self):
        return self._edition

    @edition.setter
    def edition(self, edition: PromptflowEdition):
        self._edition = edition

    def set_connection_string(self, connection_string: Optional[str]):
        """Set connection string and a context local azure log handler."""
        if not connection_string:
            return

        # Set connection string.
        if TelemetryLogHandler.CONNECTION_STRING != connection_string:
            TelemetryLogHandler.CONNECTION_STRING = connection_string

        handler = AzureLogHandler(connection_string=connection_string)
        handler.setFormatter(self._formatter)
        self._handler = handler

    def set_context(self, context: Optional[Dict[str, str]]):
        """Set log context, such as request id, workspace info."""
        if context is None:
            return
        self._context.set(context)

    def set_credential_list(self, credential_list: List[str]):
        """Set credential list, which will be scrubbed in logs."""
        self._formatter.set_credential_list(credential_list)

    def emit(self, record: logging.LogRecord):
        """Override logging.Handler's emit method."""
        # Only save telemetry log for enterprise edition.
        if self._edition != PromptflowEdition.ENTERPRISE:
            return

        if not self._handler:
            return

        # If the whole message is to be scrubbed, then do not emit.
        if self._formatter.format(record) == CredentialScrubber.PLACE_HOLDER:
            return

        # Add custom_dimensions to record
        record.custom_dimensions = self._get_custom_dimensions(record)
        # Set exc_info to None, otherwise this log will be sent to app insights's exception table.
        record.exc_info = None
        self._handler.emit(record)

    def reset_log_handler(self):
        """Reset handler."""
        if not self._handler:
            return

        connection_str = self._handler.options.get('connection_string')
        if not connection_str:
            return

        self._handler = AzureLogHandler(connection_string=connection_str)
        self._handler.setFormatter(self._formatter)

    def clear(self):
        """Close handler and clear context variable."""
        # handler = self._handler()
        if self._handler:
            self._handler.close()
        self._context.set(None)
        # self._handler.set(None)
        self._formatter.clear()

    def _get_custom_dimensions(self, record: logging.LogRecord) -> Dict[str, str]:
        custom_dimensions = self._context.get()
        if not custom_dimensions:
            custom_dimensions = dict()

        if hasattr(record, "custom_dimensions"):
            custom_dimensions.update(record.custom_dimensions)

        custom_dimensions.update({
            "processId": record.process,
            "name": record.name,
        })
        return custom_dimensions


def get_logger(name: str) -> logging.Logger:
    logger = logging.Logger(name)
    logger.addHandler(ExecutionLogHandler())
    # log to sys.stdout for backward compatibility.
    # TODO: May need to be removed in the future, after local/blob file stream are fully supported.
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setFormatter(CredentialScrubberFormatter(
        scrub_customer_content=False,
        fmt=LOG_FORMAT,
        datefmt=DATETIME_FORMAT))
    logger.addHandler(stdout_handler)
    return logger


# Logs by flow_logger will only be shown in flow mode.
# These logs should contain all detailed logs from executor and runtime.
flow_logger = get_logger('execution.flow')

# Logs by bulk_logger will only be shown in bulktest and eval modes.
# These logs should contain overall progress logs and error logs.
bulk_logger = get_logger('execution.bulk')

# Logs by logger will be shown in all the modes above,
# such as error logs.
logger = get_logger('execution')


@contextmanager
def setup_logger_context_v2(
    input_logger: logging.Logger,
    log_path: Optional[str] = None,
    app_insights_instrumentation_key: Optional[str] = None,
    credential_list: Optional[List[str]] = None,
    run_mode: RunMode = RunMode.Flow,
    context: Optional[Dict[str, str]] = None,
):
    """Setup logger context based on request info."""

    # Set log path and connection string to log handlers.
    logger_list = [input_logger, logger]
    # For bulktest and eval modes, set log path and connection string for bulk_logger,
    # otherwise for flow_logger.
    if run_mode in (RunMode.BulkTest, RunMode.Eval):
        logger_list.append(bulk_logger)
    else:
        logger_list.append(flow_logger)

    # Set log path for all loggers.
    for logger_ in logger_list:
        for log_handler in logger_.handlers:
            if isinstance(log_handler, ExecutionLogHandler):
                log_handler.set_log_path(log_path)

    # Set connection string for telemetry log handler of input_logger.
    for log_handler in input_logger.handlers:
        if isinstance(log_handler, TelemetryLogHandler):
            log_handler.set_connection_string(app_insights_instrumentation_key)
            log_handler.set_context(context)

    # Set credential list to all loggers.
    all_logger_list = [input_logger, logger, flow_logger, bulk_logger]
    credential_list = credential_list or []
    for logger_ in all_logger_list:
        for handler in logger_.handlers:
            if isinstance(handler, ExecutionLogHandler):
                handler.set_credential_list(credential_list)
            elif isinstance(handler.formatter, CredentialScrubberFormatter):
                handler.formatter.set_credential_list(credential_list)

    try:
        yield
    finally:
        # Clear context info.
        for logger_ in all_logger_list:
            for handler in logger_.handlers:
                if isinstance(handler, ExecutionLogHandler):
                    handler.clear()
                elif isinstance(handler.formatter, CredentialScrubberFormatter):
                    handler.formatter.clear()

        for log_handler in input_logger.handlers:
            if isinstance(log_handler, TelemetryLogHandler):
                log_handler.clear()


@contextmanager
def setup_logger_context(
    logger: logging.Logger,
    request: SubmitFlowRequest,
    context: Dict[str, str] = None,
    run_id: Optional[str] = None,
):
    """Setup logger context based on request info."""
    # flow_run_id is the default run id.
    if run_id is None:
        run_id = request.flow_run_id

    # Include root flow run id in context.
    if context:
        context.update({'root_flow_run_id': request.flow_run_id})

    # Get log path.
    log_path = None
    if request.run_id_to_log_path:
        log_path = request.run_id_to_log_path.get(run_id)
    with setup_logger_context_v2(
        input_logger=logger,
        app_insights_instrumentation_key=request.app_insights_instrumentation_key,
        log_path=log_path,
        credential_list=get_credential_list_from_request(request),
        run_mode=request.run_mode,
        context=context,
    ):
        yield


def set_edition(edition: PromptflowEdition, input_logger: logging.Logger):
    """Set edition for logger's handlers.

    For different editions, log handlers will have different behaviors.
    For details, refer to the comment of ExecutionLogHandler.set_log_path.
    """
    loggers = [logger, flow_logger, bulk_logger, input_logger]
    for logger_ in loggers:
        for log_handler in logger_.handlers:
            if isinstance(log_handler, ExecutionLogHandler):
                log_handler.edition = edition

            if isinstance(log_handler, TelemetryLogHandler):
                log_handler.edition = edition


def update_log_path(log_path: str):
    """Update log path for execution log handler, if it has already been set."""
    logger_list = [logger, bulk_logger, flow_logger]
    for logger_ in logger_list:
        for log_handler in logger_.handlers:
            if isinstance(log_handler, ExecutionLogHandler) and log_handler.is_log_path_set:
                log_handler.set_log_path(log_path)


def scrub_credentials(s: str):
    """Scrub credentials in string s.

    For example, for input string: "print accountkey=accountKey", the output will be:
    "print accountkey=**data_scrubbed**"
    """
    for h in logger.handlers:
        if isinstance(h, ExecutionLogHandler):
            credential_scrubber = h._formatter.credential_scrubber
            if credential_scrubber is not None:
                return credential_scrubber.scrub(s)
    return CredentialScrubber().scrub(s)


def reset_telemetry_log_handler(input_logger: logging.Logger):
    loggers = [logger, flow_logger, bulk_logger, input_logger]
    for logger_ in loggers:
        for handler in logger_.handlers:
            if isinstance(handler, TelemetryLogHandler):
                handler.reset_log_handler()
