import functools
import http
import socket
import time
import logging

import requests
import urllib3
from openai.error import APIError, OpenAIError, RateLimitError, APIConnectionError, ServiceUnavailableError, Timeout

from jinja2.exceptions import TemplateSyntaxError

OPENAI_TIMEOUT = 30  # Use a shorter timeout than default (600) to avoid hanging in flow execution


# Define the retriable exceptions
retriable_exceptions = (
    urllib3.exceptions.HTTPError,  # this is a parent class, we might not list its sub-class
    urllib3.exceptions.MaxRetryError,
    urllib3.exceptions.TimeoutError,
    urllib3.exceptions.ConnectionError,
    socket.timeout,
    http.client.RemoteDisconnected,
    http.client.HTTPException,
    requests.exceptions.ConnectionError,
    requests.exceptions.Timeout,
    requests.exceptions.RetryError,
    requests.exceptions.TooManyRedirects,
    requests.exceptions.HTTPError,
)

openai_error_code_ref_message = "Error reference: https://platform.openai.com/docs/guides/error-codes/api-errors"


def handle_openai_error():
    """
    A decorator function that used to handle OpenAI error.
    OpenAI Error falls into retriable vs non-retriable ones.

    For retriable error, the decorator use below parameters to control its retry activity with exponential backoff:
     `tries` : max times for the function invocation, type is int
     'delay': base delay seconds for exponential delay, type is float
    """

    def decorator(func):
        @functools.wraps(func)
        def wrapper(self, *args, **kwargs):
            for i in range(self.tries + 1):
                try:
                    for result in func(self, *args, **kwargs):
                        yield result
                    break
                except (RateLimitError, ServiceUnavailableError, APIError, Timeout, APIConnectionError, requests.exceptions.ConnectionError) as e:
                    #  Handle retriable exception, please refer to
                    #  https://platform.openai.com/docs/guides/error-codes/api-errors
                    logging.error(f"Exception occurs: {type(e).__name__}: {str(e)}")
                    if type(e) == RateLimitError and getattr(e.error, "type", None) == "insufficient_quota":
                        # Exit retry if this is quota insufficient error
                        logging.error(f"{type(e).__name__} with insufficient quota. Throw user error.")
                        raise Exception(to_openai_error_message(e))
                    if i == self.tries:
                        # Exit retry if max retry reached
                        logging.error(f"{type(e).__name__} reached max retry. Exit retry with user error.")
                        raise Exception(to_openai_error_message(e))
                    retry_after_in_header = e.headers.get("Retry-After", None)
                    if not retry_after_in_header:
                        retry_after_seconds = self.delay * (2**i)
                        msg = (
                            f"{type(e).__name__} #{i}, but no Retry-After header, "
                            + f"Back off {retry_after_seconds} seconds for retry."
                        )
                        logging.error(msg)
                    else:
                        retry_after_seconds = float(retry_after_in_header) * (2**i)
                        msg = (
                            f"{type(e).__name__} #{i}, Retry-After={retry_after_in_header}, "
                            f"Back off {retry_after_seconds} seconds for retry."
                        )
                        logging.error(msg)
                    time.sleep(retry_after_seconds)
                except OpenAIError as e:
                    # For other non-retriable errors from OpenAIError,
                    # For example, AuthenticationError, APIConnectionError, InvalidRequestError, InvalidAPIType
                    # Mark UserError for all the non-retriable OpenAIError
                    logging.error(f"Exception occurs: {type(e).__name__}: {str(e)}")
                    raise Exception(to_openai_error_message(e))
                except TypeError as e:
                    # For TypeError, mark UserError
                    logging.error(f"Exception occurs: {type(e).__name__}: {str(e)}")
                    error_message = f"OpenAI API hits exception: {type(e).__name__}: {str(e)}"
                    raise Exception(error_message)
                except TemplateSyntaxError as e:
                    # For TemplateSyntaxError, mark UserError
                    logging.error(f"Exception occurs: {type(e).__name__}: {str(e)}")
                    error_message = f"Failed to parse jinja2 template: {type(e).__name__}: {str(e)}"
                    raise Exception(error_message)
                except Exception as e:
                    logging.error(f"Exception occurs: {type(e).__name__}: {str(e)}")
                    error_message = f"OpenAI API hits exception: {type(e).__name__}: {str(e)}"
                    raise Exception(error_message)

        return wrapper

    return decorator


def to_openai_error_message(e: Exception) -> str:
    ex_type = type(e).__name__
    msg = str(e)
    return f"OpenAI API hits {ex_type}: {msg} [{openai_error_code_ref_message}]"
