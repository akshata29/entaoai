from dataclasses import asdict
from typing import List

from db_copilot.contract import InContextExample, InContextLearningAgent, EmbeddingModel, EmbeddingDocument
from db_copilot.contract.llm_core import LLM
from db_copilot.utils import FaissEmbeddingService


class FaissInContextLearningAgent(InContextLearningAgent):
    def __init__(self, examples: List[InContextExample],
            embedding_model: EmbeddingModel,
            rewrite_llm: LLM=None,
            rewrite_prompt=None,
            rewrite_template=None,
        ) -> None:
        
        documents = [EmbeddingDocument(text=example.embed_text, meta=asdict(example)) for example in examples]
        self._faiss = FaissEmbeddingService.from_documents(embedding_model, documents=documents)
        self.rewrite_llm = rewrite_llm
        self.rewrite_prompt = rewrite_prompt
        self.rewrite_template = rewrite_template

    def similarity_search(self, query: InContextExample, top_k: int = 4, **kwargs) -> List[InContextExample]:
        if self.rewrite_llm and self.rewrite_prompt and self.rewrite_template:
            schema = kwargs.get('schema')
            query = self.rewrite(query, schema)
        results = self._faiss.search(query.embed_text, top_k)
        return [InContextExample(**result.document.meta) for result in results]

    def rewrite(self, query: InContextExample, schema: str) -> InContextExample:
        assert self.rewrite_llm is not None
        assert self.rewrite_prompt is not None
        assert self.rewrite_template is not None
        rewrite_info = {'rewrite_prompt': self.rewrite_prompt,
                        'schema_str': schema,
                        'question': query.embed_text}
        prompt = self.rewrite_template.format_map(rewrite_info)
        rewrited_query_generator = self.rewrite_llm.chat(messages=None, prompt=prompt, max_tokens=200, stop='\n</Skill>', stream=False)
        for rewrited_query in rewrited_query_generator:
            continue
        rewrited_query = rewrited_query.split('\n')[0].strip()
        return InContextExample(embed_text=rewrited_query, prompt_text=None)


    @classmethod
    def from_question_response_session_list(
        cls,
        embedding_model: EmbeddingModel,
        question_response_session_list: List[List]
    ) -> "FaissInContextLearningAgent":
        examples = []
        for session in question_response_session_list:
            examples.append(InContextExample(
                embed_text=session[0]['question'],
                prompt_text="\n\n".join(f"<Question>\n{item['question']}\n</Question>\n{item['response'].strip()}" for item in session)
            ))
        return cls(examples, embedding_model)
