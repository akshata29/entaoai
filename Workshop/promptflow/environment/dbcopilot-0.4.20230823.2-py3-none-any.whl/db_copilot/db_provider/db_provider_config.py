import os
from dataclasses import dataclass
from typing import List, Dict

from db_copilot.contract import DictMixin, KnowledgePiece
from .grounding import GroundingConfig


@dataclass
class DBProviderConfig(DictMixin):
    """
    Config for a db provider service.
    Args:
        db_id (`str`, *required*):
            Unique id to access db provider service
        conn_string (`str`, *required*):
            A string value to connect to the database. The connect string must starts with the database type.
            For example, `sqlite://https://**/**/sample.sqlite`, `sqlserver://{{odbc_conn_string}};`.
        grounding_config (`GroundingConfig`, *optional*, defaults to `None`):
            Grounding settings. `None` will create a default `GroundingConfig` instance.
        selected_tables (`List[str]`, *optional*, defaults to `None`):
            User defined tables for the service. Default `None` will use all queried tables.
            Table name is case-sensitive.
        column_settings (`List[Dict[str, object]]`, *optional*, defaults to `None`):
            User defined settings for table/columns, such as security_level, description.
            Defaults to `None` which means no specific settings.
            The key is full name of the column which equals to `{table_name}.{column_name}`.
        metadata (`Dict[str, object]`, *optional*, defaults to `None`):
            Metadata to store dynamic values, which may be required to service building.
            For example, `db_bytes` to bytes of a database (only used for sqlite).
    """
    db_id: str
    conn_string: str = None
    grounding_config: GroundingConfig = None
    selected_tables: List[str] = None
    column_settings: List[Dict] = None
    knowledge_pieces: List[KnowledgePiece] = None
    metadata: Dict[str, object] = None

    @classmethod
    def from_dict(cls, obj: Dict) -> "DBProviderConfig":
        if 'column_settings' not in obj:
            if 'schema_settings' in obj:
                obj["column_settings"] = obj.pop("schema_settings")

        if 'grounding_config' in obj:
            obj["grounding_config"] = GroundingConfig.from_dict(obj["grounding_config"])

        if obj.get('knowledge_pieces', None):
            obj['knowledge_pieces'] = [KnowledgePiece.from_dict(x) for x in obj["knowledge_pieces"]]

        metadata = obj.pop("metadata", {})
        for key in list(obj.keys()):
            if key not in { "db_id", "conn_string", "grounding_config", "selected_tables", "column_settings", "knowledge_pieces" }:
                metadata[key] = obj.pop(key)
        obj["metadata"] = metadata
        return cls(**obj)

    def get_value(self, value: str) -> object:
        """
        Get actual value defined in this config 
        """
        # environment value
        if value.startswith("{{") and value.endswith("}}"):
            return os.getenv(value[2:-2])

        # metadata value
        if value.startswith("<<") and value.endswith(">>"):
            assert self.metadata is not None, f"Field `metadata` is require as we detect a metadata value `{value}`."
            return self.metadata.get(value[2:-2])
        
        return value
