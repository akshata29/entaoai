from pathlib import Path

from promptflow.core.tools_manager import collect_tools_from_directory


def list_package_tools():
    """List package tools"""

    shared_yaml_dir = Path(__file__).parent / "yamls/shared"
    tools = collect_tools_from_directory(shared_yaml_dir)

    try:
        from azure.identity import DefaultAzureCredential  # noqa: F401
    except ImportError:
        return tools

    azure_yaml_dir = Path(__file__).parent / "yamls/azure"
    azure_tools = collect_tools_from_directory(azure_yaml_dir)
    tools.update(azure_tools)
    return tools
