# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from promptflow._version import VERSION

USER_AGENT = "{}/{}".format("promptflow-cli", VERSION)
