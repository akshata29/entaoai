from pathlib import Path
import yaml


def collect_tools_from_directory(base_dir) -> dict:
    tools = {}
    for f in Path(base_dir).glob("**/*.yaml"):
        with open(f, "r") as f:
            tools_in_file = yaml.safe_load(f)
            for identifier, tool in tools_in_file.items():
                tools[identifier] = tool
    return tools


def list_package_tools():
    """List package tools"""

    shared_yaml_dir = Path(__file__).parent / "yamls/shared"
    tools = collect_tools_from_directory(shared_yaml_dir)

    try:
        from azure.identity import DefaultAzureCredential  # noqa: F401
    except ImportError:
        return tools

    azure_yaml_dir = Path(__file__).parent / "yamls/azure"
    azure_tools = collect_tools_from_directory(azure_yaml_dir)
    tools.update(azure_tools)
    return tools
