# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------

VERSION = "11.4.0b4"  # type: str

SDK_MONIKER = "search-documents/{}".format(VERSION)  # type: str
